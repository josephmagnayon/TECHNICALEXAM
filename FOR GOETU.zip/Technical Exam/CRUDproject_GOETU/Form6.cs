﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;
namespace CRUDproject_GOETU
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
        }
        static string constring = ConfigurationManager.ConnectionStrings["SqlConnection"].ConnectionString;

        SqlConnection con = new SqlConnection(constring);
        SqlCommand command = new SqlCommand();
        SqlDataAdapter da = new SqlDataAdapter();
        SqlDataAdapter da2 = new SqlDataAdapter();
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        DataTable dt2 = new DataTable();
        int start, recordcount;
        private void button4_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            this.Close();
            f1.Show();

        }

        private void Form6_Load(object sender, EventArgs e)
        {
            ds.Clear();
            dt.Clear();
            dt2.Clear();
            con.Open();
            da.SelectCommand = new SqlCommand("EXEC [DBO].[nsp_CustomerContactNumber] @QueryType = 0", con);
            da.Fill(ds, start, 1, "dbo.Customers");
            da.Fill(dt);
            dataGridView1.DataSource = ds.Tables[0];
            recordcount = dt.Rows.Count;
            txtcount.Text = "Number of Records: " + recordcount.ToString();
            con.Close();
            backbtn.Enabled = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ds.Clear();
            dt.Clear();
            dt2.Clear();
            if (textBox1.Text != "")
            {
                start = 0;
                con.Open();
                da.SelectCommand = new SqlCommand("EXEC [DBO].[nsp_CustomerContactNumber] @QueryType = 4 , @CUS_Lname = '" + textBox1.Text + "'", con);
                da.Fill(ds, start, 1, "dbo.Customers");
                da.Fill(dt);
                dataGridView1.DataSource = ds.Tables[0];
                recordcount = dt.Rows.Count;
                txtcount.Text = "Number of Records: " + recordcount.ToString();
                con.Close();
                if (dt.Rows.Count > 0)
                {
                    MessageBox.Show("Number of record = " + dt.Rows.Count);
                }
                else
                {
                    MessageBox.Show("data not found");

                }
            }
            else
            {
                MessageBox.Show("Please put Any of the filter");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            con.Open();
            start = 0;
            da.SelectCommand = new SqlCommand("EXEC [DBO].[nsp_CustomerContactNumber] @QueryType = 0", con);
            ds.Clear();
            dt.Clear();
            dt2.Clear();
            da.Fill(ds, start, 1, "dbo.Customers");
            da.Fill(dt);
            dataGridView1.DataSource = ds.Tables[0];
            recordcount = dt.Rows.Count;
            txtcount.Text = "Number of Records: " + recordcount.ToString();
            con.Close();
            backbtn.Enabled = false;
        }

        private void dataGridView2_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            Form7 f7 = new Form7();
            f7.hidecode.Text = this.dataGridView2.CurrentRow.Cells[0].Value.ToString();
            f7.Nname.Text = this.dataGridView2.CurrentRow.Cells[1].Value.ToString();
            //f7.textBox4.Text = this.dataGridView1.CurrentRow.Cells[1].Value.ToString();
            //f7.textBox5.Text = this.dataGridView1.CurrentRow.Cells[2].Value.ToString();
            //f7.textBox1.Text = this.dataGridView1.CurrentRow.Cells[3].Value.ToString();
            //f7.textBox2.Text = this.dataGridView1.CurrentRow.Cells[4].Value.ToString();
            //f7.textBox3.Text = this.dataGridView1.CurrentRow.Cells[5].Value.ToString();
            f7.ShowDialog();
        }

        private void backbtn_Click(object sender, EventArgs e)
        {
            start = start - 1;
            backbtn.Enabled = true;
            if (start < 0)
            {
                start = 0;
                backbtn.Enabled = false;
            }
            ds.Clear();
            dt2.Clear();
            da.Fill(ds, start, 1, "dbo.Customers");
        }

        private void nextbtn_Click(object sender, EventArgs e)
        {
            start = start + 1;
            backbtn.Enabled = true;
            if (start > recordcount)
            {
                start = 0;
            }
            ds.Clear();
            dt2.Clear();
            da.Fill(ds, start, 1, "dbo.Customers");
        }

        private void button5_Click(object sender, EventArgs e)
        {

            string code = dataGridView1.Rows[0].Cells[0].Value.ToString();
            con.Open();
            da2.SelectCommand = new SqlCommand("EXEC [DBO].[nsp_CustomerContactNumber] @QueryType = 5, @CUS_ID = '" + code + "'", con);
            dt2.Clear();
            da2.Fill(dt2);
            dataGridView2.DataSource = dt2;
            con.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form5 f5 = new Form5();
            f5.hidecode.Text = dataGridView1.Rows[0].Cells[0].Value.ToString();

            f5.ShowDialog();
        }
    }
}
