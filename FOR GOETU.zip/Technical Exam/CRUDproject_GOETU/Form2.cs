﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;
namespace CRUDproject_GOETU
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        static string constring = ConfigurationManager.ConnectionStrings["SqlConnection"].ConnectionString;

        SqlConnection con = new SqlConnection(constring);
        SqlCommand command = new SqlCommand();

        private string storedProcedureName = "[DBO].[nsp_Customers]";

        private void button3_Click(object sender, EventArgs e)
        {

            this.Hide();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            command.Connection = con;
            gender.Items.Add("Male");
            gender.Items.Add("Female");
            gender.Items.Add("Others");
        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (lname.Text == "") {MessageBox.Show("Please Fill Up First Name");}
            else if (fname.Text == "") { MessageBox.Show("Please Fill Up Last Name"); }
            else if (this.birthday.Text == "") { MessageBox.Show("Please Fill Up Birthday"); }
            else
            {
                string xfname = fname.Text, xmname = mname.Text, xlname = lname.Text, sex = gender.Text;
                DateTime xbirthday = DateTime.Parse(birthday.Text);
                con.Open();
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Clear();
                command.CommandText = storedProcedureName;
                command.Parameters.AddWithValue("@CUS_Fname", SqlDbType.NVarChar).Value = xfname;
                command.Parameters.AddWithValue("@CUS_Mname", SqlDbType.NVarChar).Value = xmname;
                command.Parameters.AddWithValue("@CUS_Lname", SqlDbType.NVarChar).Value = xlname;
                command.Parameters.AddWithValue("@CUS_Gender", SqlDbType.NVarChar).Value = sex;
                command.Parameters.AddWithValue("@CUS_Birthdate", SqlDbType.DateTime).Value = xbirthday;
                command.Parameters.AddWithValue("@QueryType", SqlDbType.Int).Value = 1;
                command.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("The Data Has been Recorded Successfully", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                lname.Clear();
                mname.Clear();
                fname.Clear();
                this.Close();

            }
          
        }


        private void textBox7_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void textBox10_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void textBox12_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void fname_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
