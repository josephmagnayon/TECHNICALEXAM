﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;

namespace CRUDproject_GOETU
{
    public partial class Form13 : Form
    {
        public Form13()
        {
            InitializeComponent();
        }

        static string constring = ConfigurationManager.ConnectionStrings["SqlConnection"].ConnectionString;

        SqlConnection con = new SqlConnection(constring);
        SqlCommand command = new SqlCommand();

        private string storedProcedureName = "[DBO].[nsp_EventAssignment]";
        private void Form13_Load(object sender, EventArgs e)
        {
            command.Connection = con;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Do you want to continue ?", "confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                con.Open();
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Clear();
                command.CommandText = storedProcedureName;
                command.Parameters.AddWithValue("@EA_ID", SqlDbType.Int).Value = Convert.ToInt32(textBox1.Text);
                command.Parameters.AddWithValue("@QueryType", SqlDbType.Int).Value = 3;
                command.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("The Data Has been Successfully Deleted", "", MessageBoxButtons.OK, MessageBoxIcon.Information);

                this.Close();
            }
        }
    }
}
