﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;


namespace CRUDproject_GOETU
{
    public partial class Form8 : Form
    {
        public Form8()
        {
            InitializeComponent();
        }
        static string constring = ConfigurationManager.ConnectionStrings["SqlConnection"].ConnectionString;

        SqlConnection con = new SqlConnection(constring);
        SqlCommand command = new SqlCommand();
        SqlDataAdapter da = new SqlDataAdapter();
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        string table = "[dbo].[EventsM]";
        int start, recordcount;
        private void button4_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            f1.Show();
            this.Close();
        }

        private void Form8_Load(object sender, EventArgs e)
        {
            ds.Clear();
            dt.Clear();
            con.Open();
            da.SelectCommand = new SqlCommand("EXEC [DBO].[nsp_EventCreation] @QueryType = 0", con);
            da.Fill(ds, start, 10, table);
            da.Fill(dt);
            dataGridView1.DataSource = ds.Tables[0];
            recordcount = dt.Rows.Count;
            txtcount.Text = "Number of Records: " + recordcount.ToString();
            con.Close();
            backbtn.Enabled = false;

        }

        private void backbtn_Click(object sender, EventArgs e)
        {
            start = start - 10;
            backbtn.Enabled = true;
            if (start < 0)
            {
                start = 0;
                backbtn.Enabled = false;
            }
            ds.Clear();
            da.Fill(ds, start, 10, table);
        }

        private void nextbtn_Click(object sender, EventArgs e)
        {
            start = start + 10;
            backbtn.Enabled = true;
            if (start > recordcount)
            {
                start = 0;
            }
            ds.Clear();
            da.Fill(ds, start, 10, table);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ds.Clear();
            dt.Clear();
            if (textBox1.Text != "" )
            {
                start = 0;
                con.Open();
                da.SelectCommand = new SqlCommand("EXEC [DBO].[nsp_EventCreation] @QueryType = 4 , @E_Name = '" + textBox1.Text + "'", con);
                da.Fill(ds, start, 10, table);
                da.Fill(dt);
                dataGridView1.DataSource = ds.Tables[0];
                recordcount = dt.Rows.Count;
                txtcount.Text = "Number of Records: " + recordcount.ToString();
                con.Close();
                if (dt.Rows.Count > 0)
                {
                    MessageBox.Show("Number of record = " + dt.Rows.Count);
                }
                else
                {
                    MessageBox.Show("data not found");

                }
            }
            else
            {
                MessageBox.Show("Please put Any of the filter");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form9 f9 = new Form9();
            f9.ShowDialog();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            Form10 f10 = new Form10();
            f10.textBox17.Text = this.dataGridView1.CurrentRow.Cells[0].Value.ToString();
            f10.textBox9.Text = this.dataGridView1.CurrentRow.Cells[5].Value.ToString();

            f10.Ename.Text = this.dataGridView1.CurrentRow.Cells[1].Value.ToString();
            f10.Edesc.Text = this.dataGridView1.CurrentRow.Cells[2].Value.ToString();
            f10.Sdate.Text = this.dataGridView1.CurrentRow.Cells[3].Value.ToString();
            f10.Edate.Text = this.dataGridView1.CurrentRow.Cells[4].Value.ToString();
            f10.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            con.Open();
            start = 0;
            da.SelectCommand = new SqlCommand("EXEC [DBO].[nsp_EventCreation] @QueryType = 0", con);
            ds.Clear();
            dt.Clear();
            da.Fill(ds, start, 10, table);
            da.Fill(dt);
            dataGridView1.DataSource = ds.Tables[0];
            recordcount = dt.Rows.Count;
            txtcount.Text = "Number of Records: " + recordcount.ToString();
            con.Close();
            backbtn.Enabled = false;
        }
    }
}
