﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;

namespace CRUDproject_GOETU
{
    public partial class Form9 : Form
    {
        public Form9()
        {
            InitializeComponent();
        }
        static string constring = ConfigurationManager.ConnectionStrings["SqlConnection"].ConnectionString;

        SqlConnection con = new SqlConnection(constring);
        SqlCommand command = new SqlCommand();

        private string storedProcedureName = "[DBO].[nsp_EventCreation]";

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (Ename.Text == "") { MessageBox.Show("Please Fill Up Event Name"); }
            else if (Edesc.Text == "") { MessageBox.Show("Please Fill Up Event Description"); }
            else if (this.Sdate.Text == "") { MessageBox.Show("Please Fill Up Start Date"); }
            else if (this.Edate.Text == "") { MessageBox.Show("Please Fill Up End Date"); }
            else
            {
                string xEname = Ename.Text, xEdesc = Edesc.Text;
                DateTime xSdate = DateTime.Parse(Sdate.Text);
                DateTime xEdate = DateTime.Parse(Edate.Text);
                con.Open();
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Clear();
                command.CommandText = storedProcedureName;
                command.Parameters.AddWithValue("@E_Name", SqlDbType.NVarChar).Value = xEname;
                command.Parameters.AddWithValue("@E_Description", SqlDbType.NVarChar).Value = xEdesc;
                command.Parameters.AddWithValue("@E_StartDate", SqlDbType.DateTime).Value = xSdate;
                command.Parameters.AddWithValue("@E_EndDate", SqlDbType.DateTime).Value = xEdate;
                command.Parameters.AddWithValue("@QueryType", SqlDbType.Int).Value = 1;
                command.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("The Data Has been Recorded Successfully", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Edesc.Clear();
                Ename.Clear();
                this.Close();

            }
        }

        private void Form9_Load(object sender, EventArgs e)
        {
            command.Connection = con;
        }
    }
}
