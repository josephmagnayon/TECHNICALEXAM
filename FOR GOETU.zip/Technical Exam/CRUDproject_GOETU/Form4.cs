﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;
namespace CRUDproject_GOETU
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }
        static string constring = ConfigurationManager.ConnectionStrings["SqlConnection"].ConnectionString;

        SqlConnection con = new SqlConnection(constring);
        SqlCommand command = new SqlCommand();
        private string storedProcedureName = "[DBO].[nsp_Customers]";
        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            fname.Enabled = true;
            mname.Enabled = true;
            lname.Enabled = true;
            gender.Enabled = true;
            birthday.Enabled = true;
            button1.Enabled = true;
            button2.Enabled = true;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Do you want to continue ?", "confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                con.Open();
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Clear();
                command.CommandText = storedProcedureName;
                command.Parameters.AddWithValue("@CUS_ID", SqlDbType.Int).Value = Convert.ToInt32(textBox17.Text);
                command.Parameters.AddWithValue("@QueryType", SqlDbType.Int).Value = 3;
                command.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("The Data Has been Successfully Deleted", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                fname.Clear();
                mname.Clear();
                lname.Clear();
                textBox17.Text = ("---");
                
                this.Close();
            }
            
        }


        private void Form4_Load(object sender, EventArgs e)
        {
            command.Connection = con;

         
            
        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (MessageBox.Show("Continue the changes ?", "confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                string xfname = fname.Text, xmname = mname.Text, xlname = lname.Text, sex = gender.Text;
                DateTime xbirthday = DateTime.Parse(birthday.Text);
                con.Open();
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Clear();
                command.CommandText = storedProcedureName;
                command.Parameters.AddWithValue("@CUS_Fname", SqlDbType.NVarChar).Value = xfname;
                command.Parameters.AddWithValue("@CUS_Mname", SqlDbType.NVarChar).Value = xmname;
                command.Parameters.AddWithValue("@CUS_Lname", SqlDbType.NVarChar).Value = xlname;
                command.Parameters.AddWithValue("@CUS_Gender", SqlDbType.NVarChar).Value = sex;
                command.Parameters.AddWithValue("@CUS_Birthdate", SqlDbType.DateTime).Value = xbirthday;
                command.Parameters.AddWithValue("@CUS_ID", SqlDbType.Int).Value = Convert.ToInt32(textBox17.Text);
                command.Parameters.AddWithValue("@QueryType", SqlDbType.Int).Value = 2;
                command.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("The Data Has been Successfully Updated", "", MessageBoxButtons.OK, MessageBoxIcon.Information);

                this.Close();
            }

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox7_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
   
        }

        private void textBox5_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void comboBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void comboBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void comboBox4_KeyUp(object sender, KeyEventArgs e)
        {

        }

        private void comboBox4_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void comboBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void textBox10_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private void textBox12_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar))
            {
                e.Handled = true;
            }
        }

    }
}
