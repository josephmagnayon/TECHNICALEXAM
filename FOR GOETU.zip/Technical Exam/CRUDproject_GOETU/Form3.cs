﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;

namespace CRUDproject_GOETU
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }
        static string constring = ConfigurationManager.ConnectionStrings["SqlConnection"].ConnectionString;

        SqlConnection con = new SqlConnection(constring);
        SqlCommand command = new SqlCommand();
        SqlDataAdapter da = new SqlDataAdapter();
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        string table = "dbo.Customers";
        int start, recordcount;

        private void Form3_Load(object sender, EventArgs e)
        {
            ds.Clear();
            dt.Clear();
            con.Open();
            da.SelectCommand = new SqlCommand("EXEC [DBO].[nsp_Customers] @QueryType = 0", con);
            da.Fill(ds,start,10, table);
            da.Fill(dt);
            dataGridView1.DataSource = ds.Tables[0];
            recordcount = dt.Rows.Count;
            txtcount.Text = "Number of Records: " + recordcount.ToString();
            con.Close();
            backbtn.Enabled = false;

            gender.Items.Add("");
            gender.Items.Add("Male");
            gender.Items.Add("Female");
            gender.Items.Add("Others");

            status.Items.Add("");
            status.Items.Add("ACTIVE");
            status.Items.Add("INACTIVE");
        }
        private void button1_Click(object sender, EventArgs e)
        {
            Form2 f2 = new Form2();
            f2.ShowDialog();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            Form4 f4 = new Form4();
            f4.gender.Items.Add("Male");
            f4.gender.Items.Add("Female");
            f4.gender.Items.Add("Others");

            f4.textBox17.Text = this.dataGridView1.CurrentRow.Cells[0].Value.ToString();
            f4.textBox9.Text = this.dataGridView1.CurrentRow.Cells[7].Value.ToString();

            f4.fname.Text = this.dataGridView1.CurrentRow.Cells[1].Value.ToString();
            f4.mname.Text = this.dataGridView1.CurrentRow.Cells[2].Value.ToString();
            f4.lname.Text = this.dataGridView1.CurrentRow.Cells[3].Value.ToString();
            f4.birthday.Text = this.dataGridView1.CurrentRow.Cells[4].Value.ToString();
            f4.gender.SelectedItem = this.dataGridView1.CurrentRow.Cells[5].Value.ToString();
            f4.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ds.Clear();
            dt.Clear();
            if (textBox1.Text != "" || gender.Text != "" || status.Text != "")
            {
                start = 0;
                con.Open();
                da.SelectCommand = new SqlCommand("EXEC [DBO].[nsp_Customers] @QueryType = 4 , @CUS_Lname = '" + textBox1.Text + "', @CUS_Gender = '" + gender.Text + "', @CUS_Status = '" + status.Text + "'", con);
                da.Fill(ds, start, 10, table);
                da.Fill(dt);
                dataGridView1.DataSource = ds.Tables[0];
                recordcount = dt.Rows.Count;
                txtcount.Text = "Number of Records: " + recordcount.ToString();
                con.Close();
                if (dt.Rows.Count > 0)
                {
                    MessageBox.Show("Number of record = " + dt.Rows.Count);
                }
                else
                {
                    MessageBox.Show("data not found");
                    
                }
            }
            else
            {
                MessageBox.Show("Please put Any of the filter");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            
            con.Open();
            start = 0;
            da.SelectCommand = new SqlCommand("EXEC [DBO].[nsp_Customers] @QueryType = 0", con);
            ds.Clear();
            dt.Clear();
            da.Fill(ds, start, 10, table);
            da.Fill(dt);
            dataGridView1.DataSource = ds.Tables[0];
            recordcount = dt.Rows.Count;
            txtcount.Text = "Number of Records: " + recordcount.ToString();
            con.Close();            
            backbtn.Enabled = false;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form1 f1 = new Form1();
            f1.Show();
            this.Close();

        }

        private void backbtn_Click(object sender, EventArgs e)
        {
            start = start - 10;
            backbtn.Enabled = true;
            if (start < 0)
            {
                start = 0;
                backbtn.Enabled = false;
            }
            ds.Clear();
            da.Fill(ds, start, 10, table);
        }


        private void nextbtn_Click(object sender, EventArgs e)
        {
            start = start + 10;
            backbtn.Enabled = true;
            if (start > recordcount)
            {
                start = 0;
            }
            ds.Clear();
            da.Fill(ds, start, 10, table);
        }
    }
}
