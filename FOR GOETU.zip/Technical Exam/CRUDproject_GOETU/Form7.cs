﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;

namespace CRUDproject_GOETU
{
    public partial class Form7 : Form
    {
        public Form7()
        {
            InitializeComponent();
        }
        static string constring = ConfigurationManager.ConnectionStrings["SqlConnection"].ConnectionString;

        SqlConnection con = new SqlConnection(constring);
        SqlCommand command = new SqlCommand();

        private string storedProcedureName = "[DBO].[nsp_CustomerContactNumber]";
        private void button1_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Continue the changes ?", "confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                string xNname = Nname.Text;
                con.Open();
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Clear();
                command.CommandText = storedProcedureName;
                command.Parameters.AddWithValue("@CN_Number", SqlDbType.NVarChar).Value = xNname;
                command.Parameters.AddWithValue("@CN_ID", SqlDbType.Int).Value = Convert.ToInt32(hidecode.Text);
                command.Parameters.AddWithValue("@QueryType", SqlDbType.Int).Value = 2;
                command.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("The Data Has been Successfully Updated", "", MessageBoxButtons.OK, MessageBoxIcon.Information);

                this.Close();
            }
        }

        private void Form7_Load(object sender, EventArgs e)
        {
            command.Connection = con;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void Nname_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((!char.IsNumber(e.KeyChar)) && (!char.IsControl(e.KeyChar)))
            {
                e.Handled = true;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Do you want to continue ?", "confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                con.Open();
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Clear();
                command.CommandText = storedProcedureName;
                command.Parameters.AddWithValue("@CN_ID", SqlDbType.Int).Value = Convert.ToInt32(hidecode.Text);
                command.Parameters.AddWithValue("@QueryType", SqlDbType.Int).Value = 3;
                command.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("The Data Has been Successfully Deleted", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Nname.Clear();

                this.Close();
            }
        }
    }
}
