﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;

namespace CRUDproject_GOETU
{
    public partial class Form12 : Form
    {
        public Form12()
        {
            InitializeComponent();
        }
        static string constring = ConfigurationManager.ConnectionStrings["SqlConnection"].ConnectionString;

        SqlConnection con = new SqlConnection(constring);
        SqlCommand command = new SqlCommand();
        SqlDataAdapter da = new SqlDataAdapter();
        DataTable dt = new DataTable();

        private string storedProcedureName = "[DBO].[nsp_EventAssignment]";
        private void button1_Click(object sender, EventArgs e)
        {
            if (Ename.Text == "") { MessageBox.Show("Please Fill Up Event Name"); }
            else if (Edesc.Text == "") { MessageBox.Show("Please Fill Up Event Description"); }
            else if (this.Sdate.Text == "") { MessageBox.Show("Please Fill Up Start Date"); }
            else if (this.Edate.Text == "") { MessageBox.Show("Please Fill Up End Date"); }
            else
            {
                string xEname = Ename.Text, xEdesc = Edesc.Text;
                DateTime xSdate = DateTime.Parse(Sdate.Text);
                DateTime xEdate = DateTime.Parse(Edate.Text);
                con.Open();
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Clear();
                command.CommandText = storedProcedureName;
                command.Parameters.AddWithValue("@EA_Name", SqlDbType.NVarChar).Value = xEname;
                command.Parameters.AddWithValue("@EA_Description", SqlDbType.NVarChar).Value = xEdesc;
                command.Parameters.AddWithValue("@CUS_ID", SqlDbType.NVarChar).Value = textBox1.Text;
                command.Parameters.AddWithValue("@E_ID", SqlDbType.NVarChar).Value = textBox2.Text;
                command.Parameters.AddWithValue("@QueryType", SqlDbType.Int).Value = 1;
                command.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("The Data Has been Recorded Successfully", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Edesc.Clear();
                Ename.Clear();
                this.Close();

            }
        }

        private void Form12_Load(object sender, EventArgs e)
        {
            
            dt.Clear();
            con.Open();
            da.SelectCommand = new SqlCommand("EXEC [DBO].[nsp_EventAssignment] @CUS_ID = '" + textBox1.Text + "',@QueryType = 4", con);
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
            command.Connection = con;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            textBox2.Text = this.dataGridView1.CurrentRow.Cells[0].Value.ToString();

            Ename.Text = this.dataGridView1.CurrentRow.Cells[1].Value.ToString();
            Edesc.Text = this.dataGridView1.CurrentRow.Cells[2].Value.ToString();
            Sdate.Text = this.dataGridView1.CurrentRow.Cells[3].Value.ToString();
            Edate.Text = this.dataGridView1.CurrentRow.Cells[4].Value.ToString();
        }
    }
}
