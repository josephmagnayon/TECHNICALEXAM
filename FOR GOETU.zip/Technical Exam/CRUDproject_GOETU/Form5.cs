﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;

namespace CRUDproject_GOETU
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
        }
        static string constring = ConfigurationManager.ConnectionStrings["SqlConnection"].ConnectionString;

        SqlConnection con = new SqlConnection(constring);
        SqlCommand command = new SqlCommand();

        private string storedProcedureName = "[DBO].[nsp_CustomerContactNumber]";

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void Form5_Load(object sender, EventArgs e)
        {
            command.Connection = con;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (Nname.Text == "") { MessageBox.Show("Please Fill Up First Name"); }
            else
            {
                string xNname = Nname.Text;
                con.Open();
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Clear();
                command.CommandText = storedProcedureName;
                command.Parameters.AddWithValue("@CN_Number", SqlDbType.NVarChar).Value = xNname;
                command.Parameters.AddWithValue("@CUS_ID", SqlDbType.NVarChar).Value = hidecode.Text;
                command.Parameters.AddWithValue("@QueryType", SqlDbType.Int).Value = 1;
                command.ExecuteNonQuery();
                con.Close();
                MessageBox.Show("The Data Has been Recorded Successfully", "", MessageBoxButtons.OK, MessageBoxIcon.Information);
                Nname.Clear();
                this.Close();

            }
        }

        private void Nname_KeyPress(object sender, KeyPressEventArgs e)
        {
            if ((!char.IsNumber(e.KeyChar)) && (!char.IsControl(e.KeyChar)))
            {
                e.Handled = true;
            }
        }
    }
}
